package com.dxc.service;

import java.util.List;

import com.dxc.model.Employee;

public interface EmployeeService {
	
	public Employee saveEmployee(Employee emp);
	
	public void deleteEmployee(Integer id);
	
	public Employee updateEmployee(Employee emp);
	
	List<Employee> getEmployee();
}
