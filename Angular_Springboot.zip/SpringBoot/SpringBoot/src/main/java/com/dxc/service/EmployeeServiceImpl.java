package com.dxc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dxc.model.Employee;
import com.dxc.repo.EmployeeRepo;


@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	public EmployeeRepo empRepo;
	
	
	@Override
	public Employee saveEmployee(Employee emp) {
		// TODO Auto-generated method stub	
		return empRepo.save(emp);
	}


	@Override
	public void deleteEmployee(Integer id) {
		// TODO Auto-generated method stub	
		Employee emp = empRepo.findById(id);
		empRepo.delete(emp);
	}


	@Override
	public Employee updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		Employee emp1 = empRepo.save(emp);
		return emp1;
	}


	@Override
	public List<Employee> getEmployee() {
		// TODO Auto-generated method stub
		return empRepo.findAll() ;
	}
}
