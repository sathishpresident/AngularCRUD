package com.dxc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.dxc.model.Employee;
import com.dxc.service.EmployeeService;


@RestController
@CrossOrigin("*")
public class EmployeeRestCtrl {

	@Autowired
	EmployeeService empservice;
	
	@RequestMapping(value = "/getemployees",method = RequestMethod.GET)
	public List<Employee> getEmployee() {
		return empservice.getEmployee();
	}
	
	@RequestMapping(value = "/deleteemployee",method = RequestMethod.POST)
	public void deleteEmployee(@PathVariable("id") int id) {
		empservice.deleteEmployee(id);
	}

	@RequestMapping(value = "/addemployee",method = RequestMethod.POST)
	public Employee saveEmployee(@RequestBody Employee user) {			
		return empservice.saveEmployee(user);
	}
	
	@RequestMapping(value = "/editemployee",method = RequestMethod.PUT)
	public Employee updateEmployee(@RequestBody Employee user) {
		return empservice.updateEmployee(user);
	}
	
}